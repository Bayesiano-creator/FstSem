Se envía un parámetro al programa: el nombre del archivo que contiene los ejemplos a evaluar.
El archivo debe contener los valores n1 x1, n2 x2,..., nk xk separados por un salto de línea,
donde ni representa el grado del polinomio y xi el valor en el que se va a evaluar, para el
i-esimo ejemplo. Se adjunta un archivo de prueba llamado "ejememplos.txt". 

Cada valor se probará con el polinomio del grado indicado y con la función exponencial que
tiene implementada la librería math.h.

La salida tendrá el siguiente formato

Grado: , valor de prueba x: 
Polinomio: , usando exp de math.h:
diferencia absoluta: 

para cada ejemplo en el archivo. 