El programa recibe un parámetro a la función main: nombre
del archivo con las operaciones a realizar. El formato de 
cada operación es debe ser

a/b@c/d 

con @ una operación en el conjunto {+,-,*,/}, y a,b,c,de
enteros. Se adjunta un archivo de ejemplo de entrada válida
con nombre "ejemplos.txt".

Todas las operaciones deben estar separadas por un salto de 
linea. Y la salida para cada operación tendrá el siguiente 
formato

a/b@c/d=x/y

con x,y enteros resultantes de la operacion.