El programa recibe un parámetro a la función main: el nombre
del archivo donde vienen los enteros a probar. Deben de
estar separados por un salto de línea. Se adjunta un archivo
de prueba llamado "ejemplos.txt". El formato de salida del 
programa es el siguiente

entero ==> entero_invertido

para cada entero en el archivo.