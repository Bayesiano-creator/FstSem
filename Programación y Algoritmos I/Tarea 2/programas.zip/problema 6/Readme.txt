El programa recibe un parámetro a la función main: el 
nombre del archivo con los ejemplos a probar. Cada ejemplos
se representa por dos enteros 

a b 

donde a es el entero decimal y b es la base a la que se quiere 
convertir. Los ejemplos deben estar separados por un salto de 
línea. Se adjunta el archivo "ejemplos.txt" para probar el programa.

El programa imprime cada ejemplo con el siguiente formato

Numero decimal: a
En base b:

Los símbolo utilizados para representar las bases son los siguientes

0,1,2,...,9,A,....,Z

en ese orden. Por lo cual solo se tienen 36 símbolos, así que el programa
no hace la conversión cuando la base es mayor a 36.