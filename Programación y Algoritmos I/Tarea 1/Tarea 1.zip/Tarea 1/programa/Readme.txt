No se envían parámetros en comando de ejecución del programa. 
Una vez ejecutado, recibe dos fracciónes con el formato:

entero/entero

con un saldo de línea al final de cada una de ellas. El programa
imprime la fracción resultante de la suma de las fracciones iniciales.  